export default function BookIcon({size=24}) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <path d="M4 3h14a2 2 0 0 1 2 2v14a1 1 0 0 1-1.5.86L14 17l-4.5 2.86A1 1 0 0 1 8 19V5a2 2 0 0 0-2-2z" stroke="black" strokeWidth="2" fill="none"/>
    </svg>
  );
}
