export default function SearchIcon({size=24}) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <circle cx="11" cy="11" r="7" stroke="black" strokeWidth="2" fill="none"/>
      <line x1="16" y1="16" x2="22" y2="22" stroke="black" strokeWidth="2"/>
    </svg>
  );
}
